class ValidationResponse:
    def __init__(self, results, data):
        self.results = results
        self.data = data

