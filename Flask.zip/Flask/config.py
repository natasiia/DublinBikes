# AWS RDS DEETS
hostname = 'dbbikes.cjkdeoopykqz.us-east-1.rds.amazonaws.com'
username = 'anastasiia'
password = 'CDb)%G79vYmqkX2n'
db_name = 'dbbikes'
port = 3306
salt = 'dqmkinhBNIBWYb bbUI768'
# JCDECAUX DEETS
APIKEY = "2796d482aba1dd5bb8b5a08e8b74067cb0c9d62d"
GOOGLE_MAPS_KEY = "AIzaSyDQW5kt6jl6wVD6p3usdVhaC-8MYOAXCn0"
NAME = "Dublin"
STATIONS_URI = "https://api.jcdecaux.com/vls/v1/stations"
